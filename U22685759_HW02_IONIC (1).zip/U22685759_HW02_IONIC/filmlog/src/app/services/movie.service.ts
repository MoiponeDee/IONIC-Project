import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Storage } from '@ionic/storage-angular';
import { Observable, map } from 'rxjs';
import { Movie } from '../models/movie.model';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class MovieService {
  private apiUrl = 'https://imdb.iamidiotareyoutoo.com/search';
  private _storage: Storage | null = null;
  selectedMovie: Movie | null = null;

  constructor(
    private http: HttpClient,
    private storage: Storage,
    private authService: AuthService
  ) {}

  async init() {
    if (!this._storage) {
      this._storage = await this.storage.create();
    }
  }

  private async userKey(key: string): Promise<string> {
    const user = await this.authService.getCurrentUser();
    const email = user?.email || 'guest';
    return `${email}_${key}`;
  }

  searchMovies(query: string): Observable<Movie[]> {
    return this.http.get<any>(`${this.apiUrl}?q=${encodeURIComponent(query)}`).pipe(
      map(response => {
        const results = response?.description || [];
        return results.map((item: any) => ({
          id: item['#IMDB_ID'] || Math.random().toString(36).slice(2),
          title: item['#TITLE'] || 'Unknown',
          year: item['#YEAR']?.toString() || '',
          poster: item['#IMG_POSTER'] || '',
          cast: (item['#ACTORS'] || '').toString(),
          description: item['#DESCRIPTION'] || ''
        }));
      })
    );
  }

  async getWatchlist(): Promise<Movie[]> {
    await this.init();
    const key = await this.userKey('watchlist');
    return (await this._storage!.get(key)) || [];
  }

  async addToWatchlist(movie: Movie): Promise<void> {
    await this.init();
    const key = await this.userKey('watchlist');
    const list: Movie[] = (await this._storage!.get(key)) || [];
    if (!list.find(m => m.id === movie.id)) {
      list.push(movie);
      await this._storage!.set(key, list);
    }
  }

  async removeFromWatchlist(movieId: string): Promise<void> {
    await this.init();
    const key = await this.userKey('watchlist');
    const list: Movie[] = (await this._storage!.get(key)) || [];
    await this._storage!.set(key, list.filter(m => m.id !== movieId));
  }

  async isInWatchlist(movieId: string): Promise<boolean> {
    const list = await this.getWatchlist();
    return !!list.find(m => m.id === movieId);
  }

  async getWatchedList(): Promise<Movie[]> {
    await this.init();
    const key = await this.userKey('watchedList');
    return (await this._storage!.get(key)) || [];
  }

  async markAsWatched(movie: Movie): Promise<void> {
    await this.init();
    const watchlistKey = await this.userKey('watchlist');
    const watchedKey = await this.userKey('watchedList');

    const watchlist: Movie[] = (await this._storage!.get(watchlistKey)) || [];
    await this._storage!.set(watchlistKey, watchlist.filter(m => m.id !== movie.id));

    const watchedList: Movie[] = (await this._storage!.get(watchedKey)) || [];
    const existing = watchedList.find(m => m.id === movie.id);
    if (existing) {
      existing.timesWatched = (existing.timesWatched || 1) + 1;
    } else {
      watchedList.push({ ...movie, timesWatched: 1 });
    }
    await this._storage!.set(watchedKey, watchedList);
  }

  async removeFromWatchedList(movieId: string): Promise<void> {
    await this.init();
    const key = await this.userKey('watchedList');
    const list: Movie[] = (await this._storage!.get(key)) || [];
    await this._storage!.set(key, list.filter(m => m.id !== movieId));
  }

  async resetTimesWatched(movieId: string): Promise<void> {
    await this.init();
    const watchlistKey = await this.userKey('watchlist');
    const watchedKey = await this.userKey('watchedList');

    const watchedList: Movie[] = (await this._storage!.get(watchedKey)) || [];
    const movie = watchedList.find(m => m.id === movieId);
    if (!movie) return;

    await this._storage!.set(watchedKey, watchedList.filter(m => m.id !== movieId));

    const watchlist: Movie[] = (await this._storage!.get(watchlistKey)) || [];
    if (!watchlist.find(m => m.id === movieId)) {
      watchlist.push({ ...movie, timesWatched: 0 });
      await this._storage!.set(watchlistKey, watchlist);
    }
  }

  async isWatched(movieId: string): Promise<boolean> {
    const list = await this.getWatchedList();
    return !!list.find(m => m.id === movieId);
  }
}