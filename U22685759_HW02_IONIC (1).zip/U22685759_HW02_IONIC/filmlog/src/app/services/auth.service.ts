import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { User } from '../models/movie.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _storage: Storage | null = null;

  constructor(private storage: Storage) {}

  async init() {
    if (!this._storage) {
      this._storage = await this.storage.create();
    }
  }

  async register(firstName: string, email: string, password: string): Promise<boolean> {
    await this.init();
    const users: User[] = (await this._storage!.get('users')) || [];
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) return false;
    users.push({ firstName, email, password });
    await this._storage!.set('users', users);
    return true;
  }

  async login(email: string, password: string): Promise<boolean> {
    await this.init();
    const users: User[] = (await this._storage!.get('users')) || [];
    const user = users.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!user) return false;
    await this._storage!.set('currentUser', user);
    return true;
  }

  async logout(): Promise<void> {
    await this.init();
    await this._storage!.remove('currentUser');
  }

  async getCurrentUser(): Promise<User | null> {
    await this.init();
    return this._storage!.get('currentUser');
  }

  async isLoggedIn(): Promise<boolean> {
    try {
      const user = await this.getCurrentUser();
      return !!user;
    } catch { return false; }
  }
}