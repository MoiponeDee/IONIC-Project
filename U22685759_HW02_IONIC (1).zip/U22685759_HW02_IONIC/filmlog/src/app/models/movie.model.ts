export interface Movie {
  id: string;
  title: string;
  year: string;
  poster: string;
  cast?: string;
  description?: string;
  timesWatched?: number;
}

export interface User {
  firstName: string;
  email: string;
  password: string;
}