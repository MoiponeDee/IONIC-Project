import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonButton, IonIcon, IonButtons,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { arrowBackOutline, addOutline, checkmarkOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../models/movie.model';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.page.html',
  styleUrls: ['./movie-detail.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonIcon,
    IonButtons
  ]
})
export class MovieDetailPage {
  selectedMovie: Movie | null = null;
  addedToWatchlist = false;
  watchedAlready = false;

  constructor(
    private router: Router,
    private movieService: MovieService,
    private toastController: ToastController
  ) {
    addIcons({ arrowBackOutline, addOutline, checkmarkOutline });
  }

  async ionViewWillEnter() {
    this.selectedMovie = this.movieService.selectedMovie;

    if (this.selectedMovie) {
      this.addedToWatchlist = await this.movieService.isInWatchlist(this.selectedMovie.id);
      this.watchedAlready = await this.movieService.isWatched(this.selectedMovie.id);
    }
  }

  async saveToWatchlist() {
    if (!this.selectedMovie) return;

    await this.movieService.addToWatchlist(this.selectedMovie);
    this.addedToWatchlist = true;

    const toast = await this.toastController.create({
      message: 'Added to Watchlist',
      duration: 2000,
      color: 'success'
    });

    await toast.present();
  }

  async moveToWatched() {
    if (!this.selectedMovie) return;

    await this.movieService.markAsWatched(this.selectedMovie);
    this.watchedAlready = true;
    this.addedToWatchlist = false;

    const toast = await this.toastController.create({
      message: 'Moved to Watched List',
      duration: 2000,
      color: 'tertiary'
    });

    await toast.present();
  }

  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      this.router.navigateByUrl('/search');
    }
  }
}