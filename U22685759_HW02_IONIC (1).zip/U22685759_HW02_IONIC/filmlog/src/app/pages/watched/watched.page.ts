import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonGrid, IonRow, IonCol, IonButton, IonIcon,
  AlertController, ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { refreshOutline, closeCircleOutline, checkmarkDoneCircleOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../models/movie.model';
import { TabBarComponent } from '../../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-watched',
  templateUrl: './watched.page.html',
  styleUrls: ['./watched.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonGrid,
    IonRow,
    IonCol,
    IonButton,
    IonIcon,
    TabBarComponent
  ]
})
export class WatchedPage {
  watchedMovies: Movie[] = [];

  constructor(
    private movieService: MovieService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {
    addIcons({ refreshOutline, closeCircleOutline, checkmarkDoneCircleOutline });
  }

  async ionViewWillEnter() {
    this.watchedMovies = await this.movieService.getWatchedList();
  }

  openMovieDetails(movie: Movie) {
    this.movieService.selectedMovie = movie;
    this.router.navigateByUrl('/movie-detail');
  }

  async deleteMovie(movie: Movie) {
    const alert = await this.alertController.create({
      header: 'Remove Movie',
      message: `Remove "${movie.title}" from Watched List?`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Remove',
          role: 'destructive',
          handler: async () => {
            await this.movieService.removeFromWatchedList(movie.id);
            this.watchedMovies = await this.movieService.getWatchedList();

            const toast = await this.toastController.create({
              message: 'Removed from Watched List',
              duration: 2000,
              color: 'warning'
            });

            await toast.present();
          }
        }
      ]
    });

    await alert.present();
  }

  async resetWatchCount(movie: Movie, event: Event) {
    event.stopPropagation();

    const alert = await this.alertController.create({
      header: 'Reset Counter',
      message: `Reset watch count for "${movie.title}"? It will move back to Watchlist.`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Reset',
          handler: async () => {
            await this.movieService.resetTimesWatched(movie.id);
            this.watchedMovies = await this.movieService.getWatchedList();

            const toast = await this.toastController.create({
              message: `"${movie.title}" moved back to Watchlist`,
              duration: 2000,
              color: 'tertiary'
            });

            await toast.present();
          }
        }
      ]
    });

    await alert.present();
  }
}