import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonSearchbar, IonButton, IonGrid, IonRow, IonCol,
  IonSpinner, IonIcon, ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { bookmarkOutline, searchOutline, logOutOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { AuthService } from '../../services/auth.service';
import { Movie } from '../../models/movie.model';
import { TabBarComponent } from '../../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonSearchbar,
    IonButton,
    IonGrid,
    IonRow,
    IonCol,
    IonSpinner,
    IonIcon,
    TabBarComponent
  ]
})
export class SearchPage {
  searchText = '';
  movieResults: Movie[] = [];
  loadingMovies = false;
  searchDone = false;

  constructor(
    private movieService: MovieService,
    private authService: AuthService,
    private router: Router,
    private toastController: ToastController
  ) {
    addIcons({ bookmarkOutline, searchOutline, logOutOutline });
  }

  handleSearchInput() {
    if (!this.searchText.trim()) {
      this.movieResults = [];
      this.searchDone = false;
    }
  }

  async findMovies() {
    if (!this.searchText.trim()) {
      this.movieResults = [];
      this.searchDone = false;
      return;
    }

    this.loadingMovies = true;
    this.searchDone = true;
    this.movieResults = [];

    this.movieService.searchMovies(this.searchText).subscribe({
      next: (results) => {
        this.movieResults = results;
        this.loadingMovies = false;
      },
      error: async () => {
        this.loadingMovies = false;

        const toast = await this.toastController.create({
          message: 'Unable to load movies. Please check your connection.',
          duration: 3000,
          color: 'danger'
        });

        await toast.present();
      }
    });
  }

  async saveToWatchlist(movie: Movie, event: Event) {
    event.stopPropagation();

    await this.movieService.addToWatchlist(movie);

    const toast = await this.toastController.create({
      message: `"${movie.title}" added to Watchlist`,
      duration: 2000,
      color: 'success',
      position: 'bottom'
    });

    await toast.present();
  }

  openMovieDetails(movie: Movie) {
    this.movieService.selectedMovie = movie;
    this.router.navigateByUrl('/movie-detail');
  }
}