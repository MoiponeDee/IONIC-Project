import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonGrid, IonRow, IonCol, IonButton, IonIcon,
  AlertController, ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { checkmarkCircleOutline, closeCircleOutline, bookmarkOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../models/movie.model';
import { TabBarComponent } from '../../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.page.html',
  styleUrls: ['./watchlist.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonGrid,
    IonRow,
    IonCol,
    IonButton,
    IonIcon,
    TabBarComponent
  ]
})
export class WatchlistPage {
  watchlistMovies: Movie[] = [];

  constructor(
    private movieService: MovieService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {
    addIcons({ checkmarkCircleOutline, closeCircleOutline, bookmarkOutline });
  }

  async ionViewWillEnter() {
    this.watchlistMovies = await this.movieService.getWatchlist();
  }

  openMovieDetails(movie: Movie) {
    this.movieService.selectedMovie = movie;
    this.router.navigateByUrl('/movie-detail');
  }

  async deleteFromWatchlist(movie: Movie) {
    const alert = await this.alertController.create({
      header: 'Remove Movie',
      message: `Remove "${movie.title}" from your Watchlist?`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Remove',
          role: 'destructive',
          handler: async () => {
            await this.movieService.removeFromWatchlist(movie.id);
            this.watchlistMovies = await this.movieService.getWatchlist();

            const toast = await this.toastController.create({
              message: 'Removed from Watchlist',
              duration: 2000,
              color: 'warning'
            });

            await toast.present();
          }
        }
      ]
    });

    await alert.present();
  }

  async moveToWatched(movie: Movie, event: Event) {
    event.stopPropagation();

    await this.movieService.markAsWatched(movie);
    this.watchlistMovies = await this.movieService.getWatchlist();

    const toast = await this.toastController.create({
      message: `"${movie.title}" moved to Watched`,
      duration: 2000,
      color: 'success'
    });

    await toast.present();
  }
}