import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonContent, IonItem, IonLabel, IonInput,
  IonButton, IonIcon, AlertController, LoadingController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { filmOutline } from 'ionicons/icons';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonItem,
    IonLabel,
    IonInput,
    IonButton,
    IonIcon
  ]
})
export class LoginPage {
  signUpMode = false;
  name = '';
  userEmail = '';
  userPassword = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertController: AlertController,
    private loadingController: LoadingController
  ) {
    addIcons({ filmOutline });
  }

  switchMode() {
    this.signUpMode = !this.signUpMode;
    this.name = '';
    this.userEmail = '';
    this.userPassword = '';
  }

  async handleSubmit() {
    if (!this.userEmail || !this.userPassword || (this.signUpMode && !this.name)) {
      const alert = await this.alertController.create({
        header: 'Missing Fields',
        message: 'Please complete all required fields.',
        buttons: ['OK']
      });

      await alert.present();
      return;
    }

    const loader = await this.loadingController.create({
      message: 'Please wait...'
    });

    await loader.present();

    try {
      if (this.signUpMode) {
        const registered = await this.authService.register(
          this.name,
          this.userEmail,
          this.userPassword
        );

        await loader.dismiss();

        if (!registered) {
          const alert = await this.alertController.create({
            header: 'Account Exists',
            message: 'This email is already linked to an existing account.',
            buttons: ['OK']
          });

          await alert.present();
          return;
        }

        await this.authService.login(this.userEmail, this.userPassword);
      } else {
        const loggedIn = await this.authService.login(
          this.userEmail,
          this.userPassword
        );

        await loader.dismiss();

        if (!loggedIn) {
          const alert = await this.alertController.create({
            header: 'Login Failed',
            message: 'Incorrect email or password.',
            buttons: ['OK']
          });

          await alert.present();
          return;
        }
      }

      this.router.navigateByUrl('/search', { replaceUrl: true });

    } catch (error) {
      await loader.dismiss();
    }
  }
}