import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = async () => {
  const authService = inject(AuthService);
  const router = inject(Router);
  try {
    await authService.init();
    const loggedIn = await authService.isLoggedIn();
    if (!loggedIn) {
      router.navigateByUrl('/login');
      return false;
    }
    return true;
  } catch {
    router.navigateByUrl('/login');
    return false;
  }
};