import { Component, NgZone } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { IonIcon } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { searchOutline, bookmarkOutline, checkmarkDoneOutline, logOutOutline } from 'ionicons/icons';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-tab-bar',
  templateUrl: './tab-bar.component.html',
  styleUrls: ['./tab-bar.component.scss'],
  imports: [CommonModule, IonIcon]
})
export class TabBarComponent {
  activeRoute = '';

  constructor(
    private router: Router,
    private zone: NgZone,
    private authService: AuthService
  ) {
    // Register icons
    addIcons({ searchOutline, bookmarkOutline, checkmarkDoneOutline, logOutOutline });

    // Set initial route
    this.activeRoute = this.router.url;

    // Listen for route changes
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.zone.run(() => {
          this.activeRoute = event.urlAfterRedirects;
        });
      }
    });
  }

  navigateTo(page: string) {
    this.zone.run(() => {
      this.router.navigateByUrl(`/${page}`);
    });
  }

  checkActive(page: string): boolean {
    return this.activeRoute.startsWith(`/${page}`);
  }

  async signOut() {
    await this.authService.logout();
    this.zone.run(() => {
      this.router.navigateByUrl('/login', { replaceUrl: true });
    });
  }
}